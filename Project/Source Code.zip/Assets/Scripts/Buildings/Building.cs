using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class Building : MonoBehaviour
{
    private StatManager statManager;
    public int houseMaxCollectionsGoldIncrease = 5;
    public float timeBetweenIncreases = 2f;
    public int goldIncrease = 1;
    public Tile placedTile;
    public string displayName = "Building";

    public void Start()
    {
        statManager = FindObjectOfType<StatManager>();
        statManager.energyBeingUsed++;
        statManager.maxCollectionGold += houseMaxCollectionsGoldIncrease;
    }
    private void Update()
    {
        timeBetweenIncreases = 1f + Mathf.Clamp(Mathf.Log(statManager.pollutionModifier, 1.06f) * 0.04f, 1f, 12f);
    }
    private void Awake()
    {
        StartCoroutine(Timer());
    }
    private IEnumerator Timer()
    {
        while (true)
        {
            yield return new WaitForSecondsRealtime(timeBetweenIncreases);
            if (statManager.energyBeingUsed <= statManager.energyBeingProvided && statManager.inCollectionGold + goldIncrease <= statManager.maxCollectionGold)
            {
                statManager.inCollectionGold += goldIncrease;
            }
            else
            {
                int difference = statManager.maxCollectionGold - statManager.inCollectionGold;
                if (difference < goldIncrease)
                {
                    statManager.inCollectionGold += difference;
                }
            }
        }
    }
}
